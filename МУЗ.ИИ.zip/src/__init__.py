"""Museum RAG Pipeline Package."""

__version__ = "1.0.0"
__author__ = "Museum RAG Team"